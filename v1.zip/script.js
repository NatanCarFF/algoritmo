document.addEventListener('DOMContentLoaded', () => {
    const historyFileInput = document.getElementById('historyFile');
    const exportHistoryButton = document.getElementById('exportHistory');
    const newSetInput = document.getElementById('newSet');
    const addSetButton = document.getElementById('addSet');
    const generateNumbersButton = document.getElementById('generateNumbers');
    const generatedSetsDiv = document.getElementById('generatedSets');
    const historyDisplayDiv = document.getElementById('historyDisplay');

    let history = []; // Armazena os conjuntos de números

    const MAX_HISTORY_SIZE = 60; // Limite de conjuntos no histórico

    // Carrega o histórico salvo no Local Storage ao iniciar
    loadHistoryFromLocalStorage();

    // Função para salvar o histórico no Local Storage
    function saveHistoryToLocalStorage() {
        localStorage.setItem('numberHistory', JSON.stringify(history));
        displayHistory();
    }

    // Função para carregar o histórico do Local Storage
    function loadHistoryFromLocalStorage() {
        const storedHistory = localStorage.getItem('numberHistory');
        if (storedHistory) {
            history = JSON.parse(storedHistory);
            displayHistory();
        }
    }

    // Função para exibir o histórico na interface
    function displayHistory() {
        historyDisplayDiv.innerHTML = '';
        if (history.length === 0) {
            historyDisplayDiv.textContent = 'Nenhum histórico disponível.';
            return;
        }
        // Exibe os conjuntos do mais novo para o mais antigo
        history.slice().reverse().forEach(set => {
            const div = document.createElement('div');
            div.textContent = set.join(', ');
            historyDisplayDiv.appendChild(div);
        });
    }

    // Event Listener para importar o histórico
    historyFileInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const importedData = JSON.parse(e.target.result);
                    if (Array.isArray(importedData) && importedData.every(set => Array.isArray(set) && set.length === 6 && set.every(num => typeof num === 'number'))) {
                        history = importedData.slice(0, MAX_HISTORY_SIZE); // Limita ao tamanho máximo
                        saveHistoryToLocalStorage();
                        alert('Histórico importado com sucesso!');
                    } else {
                        alert('Formato de arquivo JSON inválido. O arquivo deve conter um array de arrays de números (conjuntos de 6 números).');
                    }
                } catch (error) {
                    alert('Erro ao ler o arquivo JSON: ' + error.message);
                }
            };
            reader.readAsText(file);
        }
    });

    // Event Listener para exportar o histórico
    exportHistoryButton.addEventListener('click', () => {
        if (history.length === 0) {
            alert('Não há histórico para exportar.');
            return;
        }
        const dataStr = JSON.stringify(history, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'historico_numeros.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });

    // Event Listener para adicionar um novo conjunto
    addSetButton.addEventListener('click', () => {
        const input = newSetInput.value.trim();
        const numbers = input.split(',').map(num => parseInt(num.trim(), 10));

        if (numbers.length === 6 && numbers.every(num => !isNaN(num) && num >= 1 && num <= 60)) {
            // Verifica se há números repetidos no conjunto
            const uniqueNumbers = new Set(numbers);
            if (uniqueNumbers.size !== 6) {
                alert('O conjunto não pode conter números repetidos.');
                return;
            }

            history.push(numbers);
            if (history.length > MAX_HISTORY_SIZE) {
                history.shift(); // Remove o conjunto mais antigo
            }
            saveHistoryToLocalStorage();
            newSetInput.value = '';
            alert('Conjunto adicionado com sucesso!');
        } else {
            alert('Por favor, insira 6 números válidos (de 1 a 60), separados por vírgula. Ex: 01,05,12,23,45,50');
        }
    });

    // Event Listener para gerar os números
    generateNumbersButton.addEventListener('click', () => {
        if (history.length < 10) { // Um mínimo razoável para análise de probabilidade
            alert('É necessário ter pelo menos 10 conjuntos no histórico para gerar números significativos.');
            return;
        }

        const allNumbers = {};
        history.forEach(set => {
            set.forEach(num => {
                allNumbers[num] = (allNumbers[num] || 0) + 1;
            });
        });

        // Converte o objeto em um array de [numero, frequencia] e ordena por frequencia decrescente
        const sortedNumbers = Object.entries(allNumbers).sort((a, b) => b[1] - a[1]);

        // Pega os 30 números com maior probabilidade
        const top30Numbers = sortedNumbers.slice(0, 30).map(item => parseInt(item[0], 10));

        if (top30Numbers.length < 30) {
            alert('Não há números suficientes no histórico para selecionar 30 números mais prováveis. Tente adicionar mais conjuntos.');
            return;
        }

        generatedSetsDiv.innerHTML = '';
        let generatedCount = 0;
        let usedNumbers = new Set(); // Para garantir que nenhum número se repita entre os 5 conjuntos

        while (generatedCount < 5) {
            let currentSet = [];
            let availableNumbers = [...top30Numbers].filter(num => !usedNumbers.has(num));

            if (availableNumbers.length < 6) {
                alert('Não há números suficientes para gerar 5 conjuntos únicos com os 30 mais prováveis sem repetição. Redefina ou adicione mais histórico.');
                break;
            }

            // Seleciona 6 números aleatórios dos disponíveis
            for (let i = 0; i < 6; i++) {
                if (availableNumbers.length === 0) break; // Evita loop infinito se acabar os números
                const randomIndex = Math.floor(Math.random() * availableNumbers.length);
                const chosenNumber = availableNumbers[randomIndex];
                currentSet.push(chosenNumber);
                usedNumbers.add(chosenNumber);
                availableNumbers.splice(randomIndex, 1); // Remove o número para não ser escolhido novamente
            }

            if (currentSet.length === 6) {
                currentSet.sort((a, b) => a - b); // Ordena o conjunto
                const div = document.createElement('div');
                div.textContent = currentSet.join(', ');
                generatedSetsDiv.appendChild(div);
                generatedCount++;
            }
        }
    });
});